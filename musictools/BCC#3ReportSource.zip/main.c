#include <report.h>
#include <randfade.h>
#include <stdio.h>
#include <cbm.h>
#include <conio.h>
#include <string.h>
 
int main (void){
	asm("sei");

	copytext2bitmap(STARTSCRNADR, 
									BITMAPADR, 
									SCRN2ADR);
	copallchars2(CHARSETADR);
	/*Copy current text screen to hires bitmap and 
		copy ROM charset to RAM*/
					
	waitretrace();
	
	CIA2.pra = 0xc4;
	VIC.ctrl1 = 0x3b;
	VIC.addr = 0x38;
	/*Wait for retrace and then switch to hires bitmap*/
	
	randfade(PICSCRNADR, SCRN2ADR, PICBMPADR, BITMAPADR);
	/*Fade out text screen and fade in picture*/
	
	waitretrace();
	VIC.bordercolor= 0;
		
	asm("cli");
	while(!kbhit());
	cgetc();
	/*Wait for key*/
	
	asm("sei");
	
	waitretrace();
	VIC.bgcolor0 = 0;
	
	memset(PICSCRNADR, 0,0x03e8);
	memset(SCRN1ADR, 0,0x03e8);
	randfade(PICSCRNADR, SCRN2ADR, PICBMPADR, BITMAPADR);
	/*Fade out picture*/
	
	waitretrace();
	VIC.ctrl1 = 0;
	memcpy(BITMAPADR, LOGOBMPDAT, 12*0x140);
	memcpy(SCRN1ADR, LOGOSCRDAT, 12*0x28);
	memcpy(COLOR_RAM, LOGOCOLDAT, 12*0x28);
  memset(SCRN2ADR, 0x20, 0x3e8);
	/*Copy logo and clear screen for scroller*/
	
	partyon();
	/*Start scroller, no return*/
}
