#include <conio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#include <cbm.h>
#include <assert.h>
#include <ctype.h>
#include <stdint.h>
#include <string.h>

#define xsize 40
#define ysize 25

void randfade(uint8_t* scrnsrc, uint8_t* scrndest,
							uint8_t* bmpsrc, uint8_t* bmpdest){
	unsigned int randnum, counter, temp;
	int maxrand = xsize*ysize;
	//Set maxrand to size of drawing area
	unsigned int* freepos = malloc(xsize*ysize*sizeof(int));
	/*Table with numbers from 0..xsize*ysize, 
	which represent all the possible drawing positions
	*/
	
	srand(1);
	//Initialize random number generator with any number 
	
	for (counter = 0; counter < xsize*ysize; counter++){
		freepos[counter] = counter;
	}
	//Initialize Table
	
	do{
		randnum = ((unsigned long int)maxrand*rand())>>15;
		//Get random number in interval [0..maxrand]
		
		--maxrand;
		//Decrease maximum for random numbers
		
		temp = freepos[randnum];
		//Get a drawing position from random number.
		//Avoid unnecessary accesses to array elements.
		
	  scrndest[temp] = scrnsrc[temp];
	  temp *= 8;
	  memcpy(bmpdest+temp, bmpsrc+temp,8);
		//Copy graphics block to destination
		
		freepos[randnum] = (randnum!=maxrand) ? freepos[maxrand] : *freepos;
		/*No graphics block should be drawn two times at the same position, so
			update table entry with an index on a position without a drawn star.
		*/
	}
	
	while(maxrand>=0);
	
	free(freepos);
}
