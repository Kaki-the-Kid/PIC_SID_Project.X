#ifndef _RANDFADE_H
#define _RANDFADE_H
	void randfade(uint8_t* scrnsrc, uint8_t* scrndest,
							uint8_t* bmpsrc, uint8_t* bmpdest);
#endif
