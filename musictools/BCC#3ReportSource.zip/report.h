#ifndef __REPORT_H__
#define __REPORT_H__
	#include <stddef.h>
	#include <ctype.h>
	#include <stdint.h>
	#include <randfade.h>
	#include <copchar.h>
	
	extern uint8_t* _CHARSET_LOAD__;
	#define CHARSETADR ((uint8_t*) &_CHARSET_LOAD__)
	
	extern uint8_t* _BITMAP_LOAD__;
	#define BITMAPADR ((uint8_t*) &_BITMAP_LOAD__)
	
	extern uint8_t* _PICBITMAP_LOAD__;
	#define PICBMPADR ((uint8_t*) &_PICBITMAP_LOAD__)
	
	extern uint8_t* _STARTSCRN_LOAD__;
	#define STARTSCRNADR ((uint8_t*) &_STARTSCRN_LOAD__)
	
	extern uint8_t* _SCRN1_LOAD__;
	#define SCRN1ADR ((uint8_t*) &_SCRN1_LOAD__)
	
	extern uint8_t* _SCRN2_LOAD__;
	#define SCRN2ADR ((uint8_t*) &_SCRN2_LOAD__)
	
	extern uint8_t* _PICSCRN_LOAD__;
	#define PICSCRNADR ((uint8_t*) &_PICSCRN_LOAD__)
	
	extern uint8_t* logobitmap;
	#define LOGOBMPDAT ((uint8_t*) &logobitmap)
	
	extern uint8_t* scrdata;
	#define LOGOSCRDAT ((uint8_t*) &scrdata)
	
	extern uint8_t* colrdata;
	#define LOGOCOLDAT ((uint8_t*) &colrdata)
	
	void partyon(void);
	void copytext2bitmap(uint8_t* scrdat, 
				uint8_t* bmpdest, uint8_t* scrdest);
	void waitretrace(void);
#endif