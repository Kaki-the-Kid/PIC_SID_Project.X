#ifndef _COPCHAR_H
#define _COPCHAR_H
	#include <stdint.h>
	uint8_t* fastcall copchar(uint8_t whichchar, uint8_t charbankhi,
														uint8_t* dest);
	uint8_t* fastcall copallchars1(uint8_t* dest);
	uint8_t* fastcall copallchars2(uint8_t* dest);
#endif
