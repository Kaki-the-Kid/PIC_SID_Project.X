#include <stdint.h>
#include <copchar.h>
#include <cbm.h>
#include <stdio.h>

void copytext2bitmap(uint8_t* scrdat, 
	uint8_t* bmpdest, uint8_t* scrdest){
		
	uint16_t scrpos = 0;
	
	for(;scrpos<1000;++scrpos){
		bmpdest = copchar(scrdat[scrpos], (VIC.addr&2)>1, bmpdest);
		scrdest[scrpos] = ( ((uint8_t*)0xd800)[scrpos]<<4 )+(VIC.bgcolor0&15);
	}
}