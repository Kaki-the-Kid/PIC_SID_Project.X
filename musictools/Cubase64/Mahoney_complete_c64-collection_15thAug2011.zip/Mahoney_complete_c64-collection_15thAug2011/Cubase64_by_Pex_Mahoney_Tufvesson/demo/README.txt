
 Cubase64

by Pex 'Mahoney' Tufvesson, October 2010.
Released at X'2010 in the Netherlands.

If you want to encode another song, please look through
the encoder folder first. The data from the song is
in the files named SID*.s in this (the decoder) folder.

There are make files, not very complete ones, but they
do the trick for me.

The whole thing is included in the file main.s.

on Linux:  rename makefile_linux to makefile, then make run
on Win32:  rename makefile_win to makefile, then nmake.exe run

The resulting Commodore 64 executable is in the file
cubase64.prg

The resulting code is packed with pucrunch by Pasi Ojala.
The msvcr71.dll file is used by the nmake windows tool.

Sorry for not making the source code easy to follow.
And, the coding is a mess, which it has to be. :-D
But, I never said it would be easy! ;)


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
