
 Cubase64 encoder

by Pex 'Mahoney' Tufvesson, October 2010.
Released at X'2010 in the Netherlands.

For documentation, read through the files

 cubase64_1analyzePitch.m
 cubase64_2correlateWaveforms.m
 cubase64_3simplePlayback.m
 cubase64_4encodeWaveforms.m
 cubase64_5analyzeNoise.m
 cubase64_6encodeNoise.m

For executing the encoding, use Matlab with a
couple of toolboxes, 1.5GB of RAM, preferrably on
a 64-bit machine. Run the Matlab scrits in the
order above. And some 20 minutes later, copy
all the files named "SID*.s" from the encoder
folder into the demo folder, and continue there.
And, you'll need some 500MB of free disk space.

I never said it would be easy...! ;)


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
