
 Cubase64

by Pex 'Mahoney' Tufvesson, October 2010.
Released at X'2010 in the Netherlands.


This folder contains the Matlab script for generating
the tube distortion tables.
It will output the file "tube_distortion_table.s",
which you should copy into the demo folder.


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
