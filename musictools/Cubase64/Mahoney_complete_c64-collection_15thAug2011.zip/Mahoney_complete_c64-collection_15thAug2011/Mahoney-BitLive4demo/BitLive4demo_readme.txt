###
### BitLive4 demo
###  to be run on an unmodified Commodore 64
###
### Created by
###  Pex "Mahoney" Tufvesson
###
### Released on the 13th of September 2003
###

###
### Credits
###

Coding by: Pex Mahoney Tufvesson
Music: Spellbound by Rob Hubbard
The endscroller charset by Shaman of Taboo

###
### Inspiration from
###

Stable Raster IRQ by Fungus 1996
Sprite multiplexing by Lasse ��rni
Altered States by Taboo 1994, Endscroll code by MMS
Commodore 64 Programmer's Reference Guide by Project64, Ville Muikkula.

###
### Tools used for creating the BitLive4-demo:
###

CodeWright 6.0b
    text editor for win32.

Photoshop 7.0
    graphics editor for win32.

PuCrunch 8.3.2002
    by Pasi Ojala.
    Packer for win32.

XRay64 v0.1 beta3
    by Jakub 'Prezes' Wozniakowski.
    Graphics converter for win32.

dasm v2.12.04
    by Mattew Dillon
    and Olaf 'Rhialto' Seibert.

WinVice v1.12
    Commodore64 emulator

CCS64
    Commodore64 emulator.

...thanks to you all for making these wonderful
tools. Without them, this demo would never be.

###
### How to "compile"
###

With any win32-computer, run the "a.bat" script file.

This should produce the "white.prg"-file which is the demo.
"white.sym" is the symbol table,
"white.lst" is the assembly listing,
"white.bin" is the non-crunched demo.
Drag and drop this file into a running WinVice v1.12 window,
press alt-w momentarily (twice) to warp through the decrunching, and
the demo is running.

The source code is the file "white.s".

The other .bat-files are for crunching various images in the demo,
and you'll find the source files for those in the "images" folder.

###
### What to do next?
###

Make your own Commodore 64 demo? Well, why not. With this
source code, you'll get a head start.

Anyway, do whatever you like with this source code. If you
want to steal or borrow whatever routines or code, please
go ahead!

###
### Where am I?
###

You'll probably get hold of me at
http://mahoney.c64.org

Or you could try an email to
mahoney_(at)_c64_(dot)_org

Download my remixes from http://remix.kwed.org - search for "Mahoney"


Have a noise night!

###
### Pex "Mahoney" Tufvesson
### http://mahoney.c64.org
###
