###
### Exit by Mahoney
###  to be run on an unmodified Commodore 64 with a 1541
###
### Created by
###  Pex "Mahoney" Tufvesson
###
### Released on the 18th of February 2006
###  at S:t Lars meeting in Lund, Sweden
###

###
### Credits
###

Coding by: Pex Mahoney Tufvesson
Music: Yodelking and UL-Tomten
The endscroller charset by Shaman of Taboo

###
### Inspiration from
###

Stable Raster IRQ by Fungus 1996
Sprite multiplexing by Lasse ��rni
Altered States by Taboo 1994, Endscroll code by MMS
Commodore 64 Programmer's Reference Guide by Project64, Ville Muikkula.

###
### Why isn't this demo perfect?
###

Life is awesome! And it would be too bad to miss it by spending all hours of
the day correcting bugs.
So, I'm sorry for the music skipping a beat directly after the large
sprite-stretching part - and I'm sorry for the ugly graphics swapper.
But, I'm having a good time, and that's the most important thing!

You're welcome to fix these bugs for me, and send the corrected
source code to me - I'd be really happy for that! :-D

###
### Tools used for creating the BitLive4-demo:
###

CodeWright 7.5b
    text editor for win32.

Photoshop 8.0
    graphics editor for win32.

PuCrunch 8.3.2002
    by Pasi Ojala.
    Packer for win32.

XRay64 v0.1 beta3
    by Jakub 'Prezes' Wozniakowski.
    Graphics converter for win32.

dasm v2.12.04
    by Mattew Dillon
    and Olaf 'Rhialto' Seibert.

WinVice v1.19
    Commodore64 emulator

...thanks to you all for making these wonderful
tools. Without them, this demo would never be.

###
### How to "compile"
###

With any win32-computer in dos, run the "make" dos command.

This should produce the "_mahoney_exit.d64"-file which is the demo disk.
Drag and drop this file into a running WinVice v1.19 window,
and the demo is running. Please make sure that "true drive emulation"
is on, and that it has a _single_ 1541 drive attached. If you have two,
the loader will fail.

###
### What to do next?
###

Make your own Commodore 64 demo? Well, why not. With this
source code, you'll get a head start.

Anyway, do whatever you like with this source code. If you
want to steal or borrow whatever routines or code, please
go ahead!

###
### Where am I?
###

You'll probably get hold of me at
http://mahoney.c64.org

Or you could try an email to
mahoney_(at)_c64_(dot)_org

Download my remixes from http://remix.kwed.org - search for "Mahoney" and "Visa R�ster"

Also, have a listen to my a cappella group's interpretation of
Commodore 64 music. http://www.livet.se/visa
Visa R�ster has released two full-length a cappella CDs with vocal
Commodore 64 covers. Don't miss it!

There's a 5 minute video for free download at our site, from a 
concert in London where we performed International Karate - live in
front of 200 people. Check out http://www.livet.se/visa


Have a noise night!

###
### Pex "Mahoney" Tufvesson
### http://mahoney.c64.org
###
