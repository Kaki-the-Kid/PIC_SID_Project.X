// buildinc.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>

FILE *stream, *stream2;

int _tmain(int argc, _TCHAR* argv[])
{
	int version = 0;
	int numclosed;
	int numread;
	char dummy[80];

/*
	// Open for read (will fail if file "crt_fopen.c" does not exist)
	if( (stream  = fopen( "version.txt", "r+" )) == NULL )
		printf( "The file was not opened\n" );
	else
	{
		printf( "The file was opened\n" );
		numread = fread( &version, sizeof( version ), 1, stream );
//		numread = fscanf( &version, sizeof( version ), 1, stream );
		printf("%d",version);
		// Close stream
		if( fclose( stream ) )
			printf( "The file 'crt_fopen.c' was not closed\n" );
	}

	version++;

	// Open for read (will fail if file "crt_fopen.c" does not exist)
	if( (stream  = fopen( "version.txt", "w+" )) == NULL )
		printf( "The file was not wopened\n" );
	else
	{
		printf( "The file was wopened\n" );
		numread = fwrite( &version, sizeof( version ), 1, stream );
		printf("%d",version);
		// Close stream 
		if( fclose( stream ) )
			printf( "The file 'crt_fopen.c' was not closed\n" );
	}
*/

	stream = fopen( "build_number.s", "r" );
	if( stream == NULL )
		printf( "The file build_number.s was not opened\n" );
	else
	{
//		fseek( stream, 0L, SEEK_SET );
		fseek( stream, 0L, SEEK_SET );

		/* Read data back from file: */
//		fscanf( stream, "%s", dummy);
//		fscanf( stream, "%s", version );
		numread = fread( dummy, sizeof( char ), 14, stream );

		fscanf( stream, "%d", &version );
		fclose( stream );
	}

	version++;

	printf("The file 'build_number.s' says that this is build number %d.\n",version);

	// Open file in text mode: 
	if( (stream = fopen( "build_number.s", "w+t" )) != NULL )
	{
		fprintf(stream, "build_number = %d\n", version);

//      fwrite( &version, sizeof( version ), 1, stream );
		fclose( stream );
	}
	else
		printf( "Problem opening the file\n" );

	// All other files are closed:
	numclosed = _fcloseall( );
//	printf( "Number of files closed by _fcloseall: %u\n", numclosed );

//	char dummy2[4];
//	gets(dummy2);

	return 0;
}

