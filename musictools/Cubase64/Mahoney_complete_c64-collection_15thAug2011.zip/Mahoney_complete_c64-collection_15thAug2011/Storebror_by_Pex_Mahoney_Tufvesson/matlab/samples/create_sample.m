%
% Read some 44.1kHz 16-bit wav-files and convert them into
% 8-bit, 7812.5Hz unsigned, for used with Pex Mahoney Tufvessons
% "storebror" Commodore 64 demo.
%


function [] = create_sample(name)
    
format long;
format compact;

targetFs = 7812;

%[originalAudio,Fs,bits]=wavread('bd');
%[originalAudio,Fs,bits]=wavread('sd');
%[originalAudio,Fs,bits]=wavread('hh');
[originalAudio,Fs,bits]=wavread(name);


            % plot waveform
            figure(1);
            x = originalAudio;
            lenx = size(x);
            lenx = lenx(1)
            t=(0:lenx-1)/Fs;        % times of sampling instants
            subplot(3,1,1);
            plot(t,x);
            legend('Waveform');
            xlabel('Time (s)');
            ylabel('Amplitude');

            
            
    oversamplingRatio = 3;
    originalAudioX = resample(originalAudio,oversamplingRatio,1); % Use oversampling

    % Filter the audio to remove "vikningseffekten" mirroring unwanted
    % frequencies down in the pass band by exceeding the Nyqvist frequency.
    % We will have a 7812.5Hz sample rate, so we'll need to remove
    % frequencies above 3906kHz.
    % Note that we will pitch this down _after_ we've done this
    % filtering, and then pitch it back up again. So we can happily
    % use a straight 3.5kHz cutoff frequency for this one. Not really true,
    % since slices with different pitch will match to the same waveform.
    % But, hey, who's perfect? ;)

    fsamp = Fs*oversamplingRatio;
    %fcuts = [120 140 330 370];
    %mags = [0 1 0];
    %devs = [0.1 0.1 0.1];
%    fcuts = [3510 3906];
%    fcuts = [3310 3906];
    fcuts = [3710 4206];
    mags = [1 0];
    devs = [0.1 0.1];
    [n,Wn,beta,ftype] = kaiserord(fcuts,mags,devs,fsamp);
    hh = fir1(n,Wn,ftype,kaiser(n+1,beta),'noscale');
    figure(20);
    freqz(hh);

    % Make a zero-phase filtering, to make sure that
    % the slice middle index actually points to almost
    % the same spot in the audio material.
    filteredAudioX = filtfilt(hh,1,originalAudioX);

    x = resample(originalAudioX,targetFs,Fs*oversamplingRatio); % Use 8x oversampling

            
% ToDo: Correctly "truncate" the sample into a 256-byte length.
            lenx = size(x);
            lenx = lenx(1)
origLen = lenx;
actualLen1 = floor(lenx/256) * 256
actualLen2 = floor(lenx/256 + 1) * 256
x = [x' zeros(1,actualLen2-lenx)]';
lenx = size(x);
lenx = lenx(1)

            % plot waveform
            figure(1);
            lenx = size(x);
            lenx = lenx(1)
            t=(0:lenx-1)/targetFs;        % times of sampling instants
            subplot(3,1,2);
            plot(t,x);
            legend('Waveform');
            xlabel('Time (s)');
            ylabel('Amplitude');
            
            lenx = size(x);
            lenx = lenx(1)
            

% Normalize
maxx=max(x);
minx=min(x);
factor = max(abs(maxx), abs(minx));
overdrive = 1.85;
x_norm = (x ./ factor) * 32 * overdrive + 32;

% A way of "leaving at zero level", to remove clicks at the end of it
%x_norm = (x ./ factor) * 256 * overdrive + 0;

% ToDo: Make a nicer "return to zero" function.

for i = 1:lenx
    if (x_norm(i) < 0)
        x_norm(i) = 0;
    end
    if (x_norm(i) >= 63)
        x_norm(i) = 63;
    end
end


% ToDo: quantize with dithering
x_8bit = floor(x_norm);


filename = sprintf('sample_%s.s',name);
fid = fopen(filename,'w');
fprintf(fid,'; 7-bit sample for %s.\n',name);
fprintf(fid,'; this table contains %d values\n',lenx);
fprintf(fid,'; To be placed at an even 256-byte boundary in C64 memory');
fprintf(fid,'; Generated on the %s\n',date);
fprintf(fid,'; Pex Mahoney Tufvesson, 2011\n');
fprintf(fid,'\n');
%fprintf(fid,'sample_%s_start:\n',name);
for i = 1:lenx
    fprintf(fid,'  .byte %d\n',x_8bit(i));
end
%fprintf(fid,'sample_%s_end:\n',name);
fprintf(fid,'\n');
fclose(fid);


            % plot waveform
            figure(1);
            lenx = size(x_8bit);
            lenx = lenx(1)
            t=(0:lenx-1)/targetFs;        % times of sampling instants
            subplot(3,1,3);
            plot(t,x_8bit);
            legend('Waveform');
            xlabel('Time (s)');
            ylabel('Amplitude');
            




