%
% This is the fourth encoder script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%

format long;
format compact;
clear;

debugging = 1;

% Takes any song and extracts something from it.
debugging = 2;
Fs = 44100;

% Noteno, 1=55 Hz=A in octave 2
noteNo=(0:60);
twelfthRootOfTwo=2 .^ (1/12); % =1.059463094;
Hz = 55 * ( twelfthRootOfTwo .^ noteNo );


% Time to collect all wav-files into one array/matrix.
folder = 'audio_1st_try'
[v1a,Fs,bits]=wavread([folder '/vers_Xa32 - 06 - Audio - vers1']);
[v1b,Fs,bits]=wavread([folder '/vers_Xb32 - 06 - Audio - vers1']);
[v1c,Fs,bits]=wavread([folder '/vers_Xc32 - 06 - Audio - vers1']);
[v1d,Fs,bits]=wavread([folder '/vers_Xd32 - 06 - Audio - vers1']);
[v1e,Fs,bits]=wavread([folder '/vers_Xe32 - 06 - Audio - vers1']);
[v2a,Fs,bits]=wavread([folder '/vers_Xa32 - 07 - Audio - vers2']);
[v2b,Fs,bits]=wavread([folder '/vers_Xb32 - 07 - Audio - vers2']);
[v2c,Fs,bits]=wavread([folder '/vers_Xc32 - 07 - Audio - vers2']);
[v2d,Fs,bits]=wavread([folder '/vers_Xd32 - 07 - Audio - vers2']);
[v2e,Fs,bits]=wavread([folder '/vers_Xe32 - 07 - Audio - vers2']);
%[v3a,Fs,bits]=wavread([folder '/vers_Xa32 - 08 - Audio - vers3']);
%[v3b,Fs,bits]=wavread([folder '/vers_Xb32 - 08 - Audio - vers3']);
[v3c,Fs,bits]=wavread([folder '/vers_Xc32 - 08 - Audio - vers3']);
[v3d,Fs,bits]=wavread([folder '/vers_Xd32 - 08 - Audio - vers3']);
[v3e,Fs,bits]=wavread([folder '/vers_Xe32 - 08 - Audio - vers3']);
[ref,Fs,bits]=wavread([folder '/ref_X32 - 07 - Audio - vers2']);

v1a = v1a(:,1);
v1b = v1b(:,1);
v1c = v1c(:,1);
v1d = v1d(:,1);
v1e = v1e(:,1);
v2a = v2a(:,1);
v2b = v2b(:,1);
v2c = v2c(:,1);
v2d = v2d(:,1);
v2e = v2e(:,1);
%v3a = v3a(:,1);
%v3b = v3b(:,1);
v3c = v3c(:,1);
v3d = v3d(:,1);
v3e = v3e(:,1);
ref = ref(:,1);

nof_audio_files = 14;
maxlen = size(ref);
maxlen = maxlen(1)

all_audio = zeros(nof_audio_files,maxlen);

all_audio(1,1:length(v1a))=v1a;
all_audio(2,1:length(v1b))=v1b;
all_audio(3,1:length(v1c))=v1c;
all_audio(4,1:length(v1d))=v1d;
all_audio(5,1:length(v1e))=v1e;
all_audio(6,1:length(v2a))=v2a;
all_audio(7,1:length(v2b))=v2b;
all_audio(8,1:length(v2c))=v2c;
all_audio(9,1:length(v2d))=v2d;
all_audio(10,1:length(v2e))=v2e;
%all_audio(11,1:length(v3a))=v3a;
%all_audio(12,1:length(v3b))=v3b;
all_audio(11,1:length(v3c))=v3c;
all_audio(12,1:length(v3d))=v3d;
all_audio(13,1:length(v3e))=v3e;
all_audio(14,1:length(ref))=ref;

lengths = [
    length(v1a) 
    length(v1b) 
    length(v1c) 
    length(v1d) 
    length(v1e) 
length(v2a) 
length(v2b) 
length(v2c) 
length(v2d) 
length(v2e) 
length(v3c) 
length(v3d) 
length(v3e) 
length(ref) 
 ];

% Let's normalize all audio into +1.0 to -1.0 just for fun...
for audioNo=1:nof_audio_files,
    maxp = max(all_audio(audioNo,:));
    minp = min(all_audio(audioNo,:));
    coef = max(maxp, -minp);
    all_audio(audioNo,:) = all_audio(audioNo,:) ./ coef;
end

%Visualize all of the audio:
figNo = 1
%figure(figNo)
%nofInEach = 4;
%for audioNo=1:nof_audio_files,
%    figure(floor((audioNo-1) / nofInEach) + figNo)
%    subplot(nofInEach,1,audioNo - floor((audioNo-1) / nofInEach)*nofInEach);
%    a=all_audio(audioNo,:);
%    t=1:length(a);
%    plot(t,a);
%end
%figNo = figNo + 4;



% How many slices per seconds will we process?
sliceRate = 50;

% We don't care about pitch really,
% but we need it to make a constant pitch audio file...
%want to detect pitch "approximately" every XXXms.
sliceSecondsTarget = 1 / sliceRate;


% Input audio is 44100Hz, 16-bit.

% Each slice is:
sliceLength = round(Fs * sliceSecondsTarget) %#ok<NOPTS>
% This is what we really got:
sliceSeconds = sliceLength / Fs %#ok<NOPTS>
% Calculate "how wrong" the speed will be due to rounding
% the sliceLength to an integer number of 16-bit audio samples.
timeSkew = (sliceSecondsTarget - sliceSeconds) / sliceSecondsTarget %#ok<NOPTS>




%Design a highpass filter with stopband defined from 0 to 3500Hz
% and passband defined from 4000 Hz to 20 kHz.
% Specify a passband ripple of 5% and a stopband attenuation of 40 dB:

fsamp = Fs;
fcuts = [3500 4000];
mags = [0 1];
devs = [0.05 0.01];
[n,Wn,beta,ftype] = kaiserord(fcuts,mags,devs,fsamp);
hh = fir1(n,Wn,ftype,kaiser(n+1,beta),'noscale');
figure(figNo);
figNo = figNo + 1;
freqz(hh)

%Design a lowpass filter with passband defined from 0 to 3500Hz
% and stopband defined from 4000 Hz to 20 kHz.
% Specify a passband ripple of 5% and a stopband attenuation of 40 dB:
fcuts = [3500 4000];
mags = [1 0];
devs = [0.05 0.01];
[n,Wn,beta,ftype] = kaiserord(fcuts,mags,devs,fsamp);
hhlow = fir1(n,Wn,ftype,kaiser(n+1,beta),'noscale');
figure(figNo);
figNo = figNo + 1;
freqz(hhlow)


for audioNo = 1:nof_audio_files,
%Now process every phrase separately,
%since we probably won't be using all of the phrases, and
%we're pretty low on memory in the demo...


    originalAudio = all_audio(audioNo,:)';
    length = lengths(audioNo)
    t=1:length;
    nofSlices = floor(length/sliceLength)+1;

    sidCutoffFreq = zeros(1,nofSlices);  %0..22050
    rms = zeros(1,nofSlices);
    rmsHigh = zeros(1,nofSlices);
    rmsLow = zeros(1,nofSlices);
    noiseLevels = zeros(1,nofSlices);

    overlap = 0; %nofSamples to include "outside" the slice

    for sliceNo=0:nofSlices-3,
        audioStartIndex = floor((sliceNo+0)*sliceLength) + 1 -overlap
        audioEndIndex = floor((sliceNo+1)*sliceLength) + overlap - 1
        thisSliceLength = audioEndIndex-audioStartIndex

        W = hanning(thisSliceLength+1);
        % Time to estimate the noise in here:
        sliceData = detrend(originalAudio(audioStartIndex:audioEndIndex)) .* W;

        %This example uses norm(x)/sqrt(n) to obtain the root-mean-square (RMS) value of an n-element vector x.
        %x = [0 1 2 3]
        %sqrt(0+1+4+9)   % Euclidean length
        %ans =
        %    3.7417
        %norm(x)
        %ans =
        %    3.7417
        %n = length(x)   % Number of elements
        %rms = 3.7417/2  % rms = norm(x)/sqrt(n)

        len = size(sliceData);
        len = len(1);
        rms(sliceNo+1) = norm(sliceData) / len;

        % Now, extract "how much noise" there is above 4kHz.
        % If too much, be silent.
        % Make a high pass filtered version of x

        xhigh = filter(hh,1,[sliceData' zeros(1,overlap*3)]);
        rmsHigh(sliceNo+1) = norm(xhigh) / len;

        xlow = filter(hhlow,1,[sliceData' zeros(1,overlap*3)]);
        rmsLow(sliceNo+1) = norm(xlow) / len;

%        if sliceNo == 540
%            figure(figNo);
%            figNo = figNo + 1;
%            clf
%            subplot(3,1,1);
%            plot(sliceData);
%            title('sliceNo 540 just as an example');
%            subplot(3,1,2);
%            plot(xhigh);
%            subplot(3,1,3);
%            plot(xlow);
%
%        end



        yFFT = fft(sliceData);
    % Now median filter the frequency graph for each slice,
    % Since we want to estimate the noise level.
    % This will make Base frequency F0 and the formants F1 F2 F3 to
    % be filtered away, leaving only the noise.
        min_fwd = 0.0;
        min_back = 0.0;
        y_input = yFFT;
        y_fwd = yFFT;
        y_back = y_fwd;
        len = size(y_fwd(:,1));
        len = len(1);
        t2= 1:len;
        spd = 0.04;
        for i=1:len,
            %Estimate min of signal:
            min_fwd = min(min_fwd+spd, abs(y_input(i)));
            y_fwd(i) = min_fwd;
            %Estimate min of signal, backwards:
            min_back = min(min_back+spd, abs(y_input(len+1-i)));
            y_back(len+1-i) = min_back;
        end
        yFFTnoFormants=min(y_fwd,y_back);
    %    noiseLevels(sliceNo)=sum(yFFTnoFormants(1:floor(len/2))) / len; %Sum all spectra
        noiseLevels(sliceNo+1)=sum(yFFTnoFormants(ceil(4000/22050*len/2):floor(len/2))) / len; %Sum spectra above 4kHz

    end


    maxRmsHigh = max(rmsHigh);
    maxRmsLow = max(rmsLow);
    maxRms = max(rms);
    % From the plot above, we shall be silent when rmsHigh > rmsLow.
    threshold = maxRmsHigh * 0.05;

    figure(figNo);
    figNo = figNo + 1;
    clf;
    plot(rms,'y');
    hold on;
    plot(rmsHigh,'b');
    plot(rmsLow,'r');
    plot(noiseLevels,'m');
    plot([1 nofSlices],[threshold threshold],'g');
    legend('RMS','RMS for high frequencies > 4kHz','RMS for low frequencies < 4kHz','noiseLevel','threshold');
    title('Different RMS values against sliceNo');


    maxNoiseLevel = max(noiseLevels);
    thresholdNL = maxNoiseLevel * 0.25;

    figure(figNo);
    figNo = figNo + 1;
    clf;
    plot(noiseLevels,'m');
    hold on;
    plot([1 nofSlices],[thresholdNL thresholdNL],'g');
    legend('noiseLevel','threshold');
    title('noiseLevels agains threshold');

    sidNoiseVolume = zeros(1,nofSlices); %0,1,2,3..15
    for sliceNo=1:nofSlices-2,


    %    % One stupid way of doing it:
    %    if ((rmsHigh(sliceNo) > rmsLow(sliceNo)) && (rmsHigh(sliceNo) > threshold))
    %        sidNoiseVolume(sliceNo) = 15;
    %    end


    %     a = rmsHigh(sliceNo) - threshold;
    %     d = a / ((maxRmsHigh) * 0.50); %All above 50% of max level will be max.
    %     e = ceil(d * 15);
    %     if (e > 15)
    %         e = 15;
    %     end
    %     if (e < 0)
    %         e = 0;
    %     end
    %     sidNoiseVolume(sliceNo) = e;


        % One stupid way of doing it:
    %    if ((rmsHigh(sliceNo) > rmsLow(sliceNo)) && (rmsHigh(sliceNo) > threshold))
        if ((noiseLevels(sliceNo) > thresholdNL))
            a = noiseLevels(sliceNo) - thresholdNL;
            d = a / ((maxNoiseLevel) * 0.90); %All above 90% of max level will be max.
    %        e = floor(d * 15);
            e = d * 15;
            if (e > 15)
                e = 15;
            end
            if (e < 0)
                e = 0;
            end
            sidNoiseVolume(sliceNo) = e;
            
            %The refrain should have less noise in it...
            if (audioNo == 14)
                sidNoiseVolume(sliceNo) = floor(e / 2);
            end
            
        end


    end

%    sidNoiseVolume(1:150) = 0; %Just skip the noise for the first "I am" in Tom's Diner

    figure(figNo);
    figNo = figNo + 1;
    clf
    plot(sidNoiseVolume);
    title('sidNoiseVolume');


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    %Now, time to encode the noise into something smaller...
    
    
    

    nofSlices = size(sidNoiseVolume);
    nofSlices = nofSlices(2)

    if debugging==1
        % Everything above minNoiseLevel shall be considered as Noise
%        figure(figNo);
%        figNo = figNo + 1;
%        clf;
%        x=1:nofSlices;
%        plot(x,sidNoiseVolume);
%        hold on;
%        plot(x,sidNoiseVolume,'r.');
%        title('SID Noise level per slice');
%        xlabel('sliceNo');
%        ylabel('d406');
%        axis([0 nofSlices -1 16]);

%        figure(figNo);
%        figNo = figNo + 1;
%        clf;
%        plot(x,sidCutoffFreq);
%        title('SID high pass filter cutoff freq per slice');
%        xlabel('sliceNo');
%        ylabel('cutoffFreq');
%        axis([0 nofSlices -100 10300]);
    end


    % Need to compress the data, to make sure that it
    % fits into very little memory, and that the
    % uncompressing of data would require almost _no_
    % computations.

    %$d416 $d417 $d418
    %   0   $01    $4f: All pass filter
    %  32   $01    $4f: High pass -3dB@1kHz
    %  64   $01    $4f: High pass -3dB@2kHz
    %  128  $01    $4f: High pass -3dB@6kHz
    %  192  $01    $4f: High pass -3dB@8kHz
    %  255  $01    $4f: High pass -3dB@10kHz
    %
    %  64   $81    $4f: High pass -3dB@2kHz, with +10dB@3kHz
    % 128   $81    $4f: High pass -3dB@6kHz, with +7dB@7kHz

    SIDd416 = zeros(1,nofSlices);
    SIDd416 = floor(sidCutoffFreq / 10000 * 255);
    SIDd416 = max(SIDd416,0);
    SIDd416 = min(SIDd416,255);

%    figure(figNo);
%    figNo = figNo + 1;
%    clf;
%    x=1:nofSlices;
%    plot(x,sidCutoffFreq);
%    title('SID high pass filter cutoff freq per slice');
%    xlabel('sliceNo');
%    ylabel('$d416');
%    axis([0 nofSlices -10 265]);





    %$D405  54277	
    %Voice #1 Attack and Decay length. Bits:
    %Bits #0-#3: Decay length. Values:
    %0000, 0: 6 ms.
    %0001, 1: 24 ms.
    %0010, 2: 48 ms.
    %0011, 3: 72 ms.
    %0100, 4: 114 ms.
    %0101, 5: 168 ms.
    %0110, 6: 204 ms.
    %0111, 7: 240 ms.
    %1000, 8: 300 ms.
    %1001, 9: 750 ms.
    %1010, 10: 1.5 s.
    %1011, 11: 2.4 s.
    %1100, 12: 3 s.
    %1101, 13: 9 s.
    %1110, 14: 15 s.
    %1111, 15: 24 s.
    %Bits #4-#7: Attack length. Values:
    %0000, 0: 2 ms.
    %0001, 1: 8 ms.
    %0010, 2: 16 ms.
    %0011, 3: 24 ms.
    %0100, 4: 38 ms.
    %0101, 5: 56 ms.
    %0110, 6: 68 ms.
    %0111, 7: 80 ms.
    %1000, 8: 100 ms.
    %1001, 9: 250 ms.
    %1010, 10: 500 ms.
    %1011, 11: 800 ms.
    %1100, 12: 1 s.
    %1101, 13: 3 s.
    %1110, 14: 5 s.
    %1111, 15: 8 s.
    %Write-only.
    %$D406
    %54278	
    %Voice #1 Sustain volume and Release length. Bits:
    %Bits #0-#3: Release length. Values:
    %0000, 0: 6 ms.
    %0001, 1: 24 ms.
    %0010, 2: 48 ms.
    %0011, 3: 72 ms.
    %0100, 4: 114 ms.
    %0101, 5: 168 ms.
    %0110, 6: 204 ms.
    %0111, 7: 240 ms.
    %1000, 8: 300 ms.
    %1001, 9: 750 ms.
    %1010, 10: 1.5 s.
    %1011, 11: 2.4 s.
    %1100, 12: 3 s.
    %1101, 13: 9 s.
    %1110, 14: 15 s.
    %1111, 15: 24 s.
    %Bits #4-#7: Sustain volume.
    %Write-only.




    % Use a clock freqency of 985248Hz for PAL C64


    %// The audio output stage in a Commodore 64 consists of two STC networks,
    %// a low-pass filter with 3-dB frequency 16kHz followed by a high-pass
    %// filter with 3-dB frequency 16Hz (the latter provided an audio equipment
    %// input impedance of 1kOhm). 


    %reg16 EnvelopeGenerator::rate_counter_period[] = {
    %      9,  //   2ms*1.0MHz/256 =     7.81
    %     32,  //   8ms*1.0MHz/256 =    31.25
    %     63,  //  16ms*1.0MHz/256 =    62.50
    %     95,  //  24ms*1.0MHz/256 =    93.75
    %    149,  //  38ms*1.0MHz/256 =   148.44
    %    220,  //  56ms*1.0MHz/256 =   218.75
    %    267,  //  68ms*1.0MHz/256 =   265.63
    %    313,  //  80ms*1.0MHz/256 =   312.50
    %    392,  // 100ms*1.0MHz/256 =   390.63
    %    977,  // 250ms*1.0MHz/256 =   976.56
    %   1954,  // 500ms*1.0MHz/256 =  1953.13
    %   3126,  // 800ms*1.0MHz/256 =  3125.00
    %   3907,  //   1 s*1.0MHz/256 =  3906.25
    %  11720,  //   3 s*1.0MHz/256 = 11718.75
    %  19532,  //   5 s*1.0MHz/256 = 19531.25
    %  31251   //   8 s*1.0MHz/256 = 31250.00
    %};


    %// From the sustain levels it follows that both the low and high 4 bits of the
    %// envelope counter are compared to the 4-bit sustain value.
    %// This has been verified by sampling ENV3. 

    % The ADSR bug can be triggered when Attack-rate/decay-rate or
    % release rate is changed to a "faster" value than before.
    % To avoid this, never change these values.
    % Or, do a 33ms "pause" with ADSR all set to "0" - before starting another
    % ADSR cycle.

    % These pauses would require two separate noise voices.
    % One could be in "reset" state while the other one is sounding.

    % Solution: Always keep attack/sustain/release rate at 0


    sliceNo = 5;
    encIndex = 1;
    enc = zeros(1,40000); %Just a guess. A really bad one as well.

    while sliceNo < nofSlices,
        %First, skip through all zeroes:

        ticksToWait = 1;
        %Silence must be at least 5 slices, to make room for attack/decay
        while (((sidNoiseVolume(sliceNo) < 0.75) && (ticksToWait < 254) && (sliceNo < nofSlices-1)) || (ticksToWait <= 4)),
            sliceNo = sliceNo + 1;
            ticksToWait = ticksToWait + 1;
        end
        sliceNo = sliceNo + 1;
        startSlice = sliceNo;

        % Then count how long the noise should be:
        ticksToSound = 1;
        while (((sliceNo < nofSlices-4) && (sidNoiseVolume(sliceNo) + sidNoiseVolume(sliceNo+1) + sidNoiseVolume(sliceNo+2) + sidNoiseVolume(sliceNo+3)) > 0.9) && (ticksToSound < 254)),
            sliceNo = sliceNo + 1;
            ticksToSound = ticksToSound + 1;
        end
        sliceNo = sliceNo + 1;
        endSlice = sliceNo;

        len = startSlice-endSlice
        %ToDo: characterize the noise from startSlice to endSlice.
        %Extract cutoff freq + filter type

        %Now, we need to make an "average noise level" of all the
        %slices that should be sounding. Make a constant amplitude of the noise
        volume = sum(sidNoiseVolume(startSlice:endSlice-1))/(endSlice-startSlice)
        volume = ceil(volume);
        volume = max(1,volume);
        volume = min(16,volume);
        if (ticksToWait == 255)
            volume = 0;
            ticksToWait = -1;
            enc(encIndex) = ticksToWait+1;
            encIndex = encIndex + 1;
            enc(encIndex) = volume * 16;
            encIndex = encIndex + 1;
            sliceNo = sliceNo - 1;
        else
            enc(encIndex) = ticksToWait+1;
            encIndex = encIndex + 1;
            enc(encIndex) = volume * 16;
            encIndex = encIndex + 1;
            enc(encIndex) = ticksToSound+1;
            encIndex = encIndex + 1;
        end


    end

    enc = enc(1:encIndex);
    enc(encIndex-3) = 0;
    enc(encIndex-2) = 0;
    enc(encIndex-1) = 0; %End of everything marker (ticksToSound = 0)


    % Dump the encoded data into a file

    filename = sprintf('../demo/SIDencodedNoise_%d.s',audioNo);
    fid = fopen(filename,'w');
    fprintf(fid,'; encoded Noise generated by storebror_04_noise_analysis.m\n');
    fprintf(fid,'; this table contains %d values\n',encIndex);
    fprintf(fid,'; Generated on the %s\n',date);
    fprintf(fid,'; Pex Mahoney Tufvesson, 2011\n');
    fprintf(fid,'\n');
    for i=1:encIndex-1,
        fprintf(fid,'  .byte %d\n',enc(i));
    end
    fprintf(fid,'; End of generated data\n');
    fprintf(fid,'\n');
    fclose(fid);



    % Time to visualize the encoded Noise:

    noiseOutput = zeros(1,nofSlices);
    noiseIndex = 1;
    encIndexEnd = encIndex;
    encIndex = 1;
    while encIndex < encIndexEnd,
        ticksToWait = enc(encIndex);
        encIndex = encIndex + 1;
        nextVol = enc(encIndex);
        encIndex = encIndex + 1;
        if ticksToWait == 0
            ticksToWait = 256;
        end
        noiseOutput(noiseIndex:noiseIndex+ticksToWait-1) = 0;
        noiseIndex = noiseIndex + ticksToWait;

        if (ticksToWait ~= 256)
            ticksToSound = enc(encIndex);
            encIndex = encIndex + 1;
            noiseOutput(noiseIndex:noiseIndex+ticksToSound-1) = nextVol;
            noiseIndex = noiseIndex + ticksToSound;
        end
    end

    figure(figNo);
    figNo = figNo + 1;
    clf;
    plot(noiseOutput);
    title('noiseOutput after encoding');
    hold on;
    plot(noiseOutput,'r.');



    %sound(y(1:previewSamples),44100,16);


    
end







%  dec ticksToWait
%  bne nothing
%where:
%  beq on/off
%on:
%  lda #$81  ;Yes, it's time for noise!
%  sta $d404
%  ldy #0
%  lda (noisePoi),y
%  sta ticksToWait   ;How long will this noise be?
%  inc noisePoi+1
%  bne noWrr
%  inc NoisePoi
%  lda #off
%  sta where+1
%  rts
%off:
%  lda #$80  ;shut up!
%  sta $d404
%  ldy #0
%  lda (noisePoi),y
%  sta ticksToWait    ;How long will this silence be?
%  bne notQuit
%  lda #1
%  sta finished   ;We're all done, let's go home
%notQuit:
%  inc noisePoi+1
%  bne noWrr2
%  inc NoisePoi
%noWrr2:
%noWrr:
%  lda (noisePoi),y
%  sta $d406   ;Set sustain level for next noise
%  inc noisePoi+1
%  bne noWrr3
%  inc NoisePoi
%noWrr3:
%  lda #on
%  sta where+1
%  rts


