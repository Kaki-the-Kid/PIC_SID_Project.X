%
% This is a helper script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%

% This will read the CSAM V3-generated codebook,
% and make transition tables.
% Take one character, analyse it, and make a table of 
% "which character shall I replace this with to make
% the whole graphics smaller"
% We're only allowed to remove pixels, not add any.
% And, whenever we remove the "first pixels on an edge"
% we shall also start to turn "completely white neighbour chars"
% into a char where something on the same edge missing, ideally
% in the same position".

% So, there's a lot of analyzing to be done.


format long;
format compact;
clear;

nof_chars = 256;

filename = sprintf('../demo/gra_Codebook_c64_5.raw');
fid = fopen(filename,'r');
codebook = fread(fid,nof_chars*8,'uchar');
size(codebook)
fclose(fid);

%The codebook is 256 lists with 8*8 bits in each.
codematrix = zeros(nof_chars,8,8);

% de-Invert the codebook, since it is inverted already...
for char=0:nof_chars-1,
    for y=0:7,
        for x=0:7,
            codematrix(char+1,x+1,y+1) = 1 - (bitand(power(2,7-x), codebook(y+char*8+1)) > 0);
        end
    end
end


% Now, we have all chars as bit matrices in the codematrix

score = zeros(nof_chars,nof_chars);
illegal_score = zeros(nof_chars,nof_chars);
illegal_nof = zeros(nof_chars,nof_chars);
% Lets pick one char, and "sort" all the others according to this char...
for source_char=0:nof_chars-1,
    for cmp_char=0:nof_chars-1,
        if (source_char ~= cmp_char)  %Don't compare the char against itself...
            % Score: 0 = "illegal transition" it's bad, so don't do it.
            % The higher score, the better.
            % Highest score is "number of lit pixels" in source_char
            tmp_score = sum(sum(codematrix(source_char+1,:,:) & codematrix(cmp_char+1,:,:)));
            %Now we need to check if there are any "illegal" pixels.
            % If there's a '1' anywhere in cmp_char when source_char is '0'
            % make this an illegal transition...
            illegal = sum(sum((1.-codematrix(source_char+1,:,:)) & codematrix(cmp_char+1,:,:)));
            if (illegal > 0)
                illegal_nof(source_char+1,cmp_char+1) = illegal;
                illegal_score(source_char+1,cmp_char+1) = tmp_score;
            else
                score(source_char+1,cmp_char+1) = tmp_score;
            end
        end
    end
end

% Now we have a score matrix.
% The score is "how many pixels were right".
% Having the exact same number of pixels is bad.
% And the illegal matrix tells _how_many_wrong_pixels_ do we have in this
% transition.

% So, let's zero out all "equal number of pixels"
for source_char=0:nof_chars-1,
    max_score = sum(sum(codematrix(source_char+1,:,:) & codematrix(source_char+1,:,:)));
    for cmp_char=0:nof_chars-1,
        if (score(source_char+1,cmp_char+1) == max_score)
            score(source_char+1,cmp_char+1) == -1;
        end
    end
end
        
%We need to find the "empty" char...
%...this is where we're going when there's nothing else that's better...
empty_char = -1;
for char=0:nof_chars-1,
    if (sum(sum(codematrix(char+1,:,:))) == 0)
        if (empty_char == -1)
            empty_char = char
        end
    end
end


% Remove all scores for transitions that don't remove a pixel that is
% a neighbour to an already gone pixel.
for src_char=0:nof_chars-1,

    % set "edge pixels" to one in the must_remove matrix
    must_remove = zeros(1,8,8);
    
    
    for y=0:7,
        %from left to right
        state = 0;
        for x=0:7,
            if (codematrix(src_char+1,x+1,y+1) == 0)
                if (state==0)
                    state = 1;
                end
            else
                if (state == 1)
                    must_remove(1,x+1,y+1) = 1;
                    state = 2;
                end
            end
        end

        %from right to left
        state = 0;
        for x=7:-1:0,
            if (codematrix(src_char+1,x+1,y+1) == 0)
                if (state==0)
                    state = 1;
                end
            else
                if (state == 1)
                    must_remove(1,x+1,y+1) = 1;
                    state = 2;
                end
            end
        end
    end
    

    for x=0:7,
        %from top to bottom
        state = 0;
        for y=0:7,
            if (codematrix(src_char+1,x+1,y+1) == 0)
                if (state==0)
                    state = 1;
                end
            else
                if (state == 1)
                    must_remove(1,x+1,y+1) = 1;
                    state = 2;
                end
            end
        end

        %from bottom to top
        state = 0;
        for y=7:-1:0,
            if (codematrix(src_char+1,x+1,y+1) == 0)
                if (state==0)
                    state = 1;
                end
            else
                if (state == 1)
                    must_remove(1,x+1,y+1) = 1;
                    state = 2;
                end
            end
        end
    end
    
    %Now, check this transition.
    %We have a matrix with '1' in every position that is an edge
    % in the src_char.
    %Now, check all other chars, and make sure that they _do_ remove
    % one of the must_remove ones. If not, it's not a good transition.
    
    for cmp_char=0:nof_chars-1,
        if (sum(sum(must_remove & codematrix(cmp_char+1,:,:))) == 0)
            %not a good transition...
 %Don't do this right now...
            %           score(src_char+1,cmp_char+1) = 0;
            %must_remove
            %codematrix(cmp_char+1,:,:)
            
        end
    end

    
end







% To find a good transition, we need to sort the score matrix.
% Or, just find the max.

% Select the transition that zeros out the least number of corners.
% We want to save the corners for as long as possible...
% Add 100*(corners left) to the score... or something less precise.
% Maybe 12*(corners left in cmp_char...

for src_char=0:nof_chars-1,
    for cmp_char=0:nof_chars-1,
        corners_left = 0;
        if (codematrix(cmp_char+1,1,1) == 1)
            corners_left = corners_left + 1;
        end
        if (codematrix(cmp_char+1,1,8) == 1)
            corners_left = corners_left + 1;
        end
        if (codematrix(cmp_char+1,8,1) == 1)
            corners_left = corners_left + 1;
        end
        if (codematrix(cmp_char+1,8,8) == 1)
            corners_left = corners_left + 1;
        end
        if (score(src_char+1,cmp_char+1) > 0)
            score(src_char+1,cmp_char+1) = score(src_char+1,cmp_char+1) + 1 * corners_left;
        end
    end
end


transition = zeros(nof_chars,1);

for source_char=0:nof_chars-1,
    [maxval, index] = max(score(source_char+1,:));
    if (maxval ~= 0)
        transition(source_char+1) = index-1;
    else
        % Let's go to blank, if there's nothing else that fits better...
        transition(source_char+1) = empty_char;
    end
end

% And, for the "completely white" char, don't do any transition...
% or, transition into itself...!
filled_char = -1;
for char=0:nof_chars-1,
    if (sum(sum(codematrix(char+1,:,:))) == 64)
        if (filled_char == -1)
            filled_char = char
        end
        %Let all filled chars transition into the first filled char...
        transition(char+1) = filled_char;
    end
end






% Now, we should probably find the nicest way of fading a completely
% white char into something darker.
% We can start by sorting all chars from whitest to darkest...

nof_white_pixels = zeros(nof_chars,1);
for char=0:nof_chars-1,
    nof_white_pixels(char+1) = sum(sum(codematrix(char+1,:,:)));
end

% We could find "the whitest char" with a certain pixel unset, for
% instance.

whitest_with_topleft_missing = -1;
whitest_with_bottomleft_missing = -1;
whitest_with_topright_missing = -1;
whitest_with_bottomright_missing = -1;

whitest_with_topleft_missing_nof_white = -1;
whitest_with_bottomleft_missing_nof_white = -1;
whitest_with_topright_missing_nof_white = -1;
whitest_with_bottomright_missing_nof_white = -1;


for char=0:nof_chars-1,
    if (codematrix(char+1,1,1) == 0)
        if (nof_white_pixels(char+1) > whitest_with_topleft_missing_nof_white)
            whitest_with_topleft_missing_nof_white = nof_white_pixels(char+1);
            whitest_with_topleft_missing = char;
        end
    end
    if (codematrix(char+1,8,1) == 0)
        if (nof_white_pixels(char+1) > whitest_with_topright_missing_nof_white)
            whitest_with_topright_missing_nof_white = nof_white_pixels(char+1);
            whitest_with_topright_missing = char;
        end
    end
    if (codematrix(char+1,1,8) == 0)
        if (nof_white_pixels(char+1) > whitest_with_bottomleft_missing_nof_white)
            whitest_with_bottomleft_missing_nof_white = nof_white_pixels(char+1);
            whitest_with_bottomleft_missing = char;
        end
    end
    if (codematrix(char+1,8,8) == 0)
        if (nof_white_pixels(char+1) > whitest_with_bottomright_missing_nof_white)
            whitest_with_bottomright_missing_nof_white = nof_white_pixels(char+1);
            whitest_with_bottomright_missing = char;
        end
    end
end

% Let's write the transition table into a source-file...

filename = sprintf('../demo/graphics_transitions.s');
fid = fopen(filename,'w');
fprintf(fid,'; Graphics transition tables.\n');
fprintf(fid,'; Generated on the %s\n',date);
fprintf(fid,'; Pex Mahoney Tufvesson, 2011\n');
fprintf(fid,'\n');
fprintf(fid,'transitions:\n');
for char=0:nof_chars-1,
    fprintf(fid,'  .byte %d ;char %d will be set to %d', transition(char+1), char, transition(char+1));
    if (transition(char+1) == empty_char)
        fprintf(fid,' ... which is empty, btw');
    end
    fprintf(fid,'\n');
end
fprintf(fid,'empty_char=%d\n',empty_char);
fprintf(fid,'filled_char=%d\n',filled_char);
fprintf(fid,'filled_topleft_char=%d\n',whitest_with_topleft_missing);
fprintf(fid,'filled_topright_char=%d\n',whitest_with_topright_missing);
fprintf(fid,'filled_bottomleft_char=%d\n',whitest_with_bottomleft_missing);
fprintf(fid,'filled_bottomright_char=%d\n',whitest_with_bottomright_missing);
fclose(fid);


