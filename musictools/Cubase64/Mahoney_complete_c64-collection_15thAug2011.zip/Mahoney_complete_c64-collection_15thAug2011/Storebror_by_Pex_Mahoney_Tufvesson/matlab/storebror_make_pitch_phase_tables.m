%
% This is the first encoder script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%

format long;
format compact;
clear;

% Takes any song and extracts something from it.
debugging = 2;

% Noteno, 1=55 Hz=A in octave 2
noteNo=(0:60);
twelfthRootOfTwo=2 .^ (1/12); % =1.059463094;
Hz = 55 * ( twelfthRootOfTwo .^ noteNo );

%;Vers:
%;Akta dig f�r storebror
%;c2c2 c2  b1  b1 a1 a1
%;Han ser mera �n du n�nsin tror
%;g1  a1  b1b1 b1 a1 a1 g1  g1
%;N�tet pejlas in ikv�ll
%;e1 g1 e1 d1  d1 c1 c1 
%;Du e kanske kriminell
%;c1 d1 e1g1  e1 d1 e1
%
%;inte facebook
%;b0d1 b0  a0
%
%;Anv�nda noter i vers:   9st  a0-c2
%;c2 b1 a1 g1 e1 d1 c1 b0 a0
%
%;Ref:
%;Hur har det kunnat bli s� kallt
%;b1  b1  b1  a1 a1  g1  g1  f#1
%;d1  d1  d1  c#1c#1 d1  d1  d1
%;b0  b0  b0  b0 b0  b0  b0  b0
%;storebror vet inte   allt
%;b1 b1 a1  a1  a1g1   f#1
%;a1 e1 f#1 g1  e1e1   d1
%;b0 c#1d1  e1  c#1c#1 b0
%;k�rlek skratt en doft av kl�ver
%;b1 b1  a1     a1 g1   g1 f#1f#1
%;d1 g1  e1     f#1e1   f#1d1 d1
%;b0 d1  c#1    d1 c#1  f1 b0 b0
%;det �r s�nt som vi beh�ver
%;b1  b1 a1   a1  a1 g1f#1f#1
%;f#1 f#1f1   e1  e1 e1e1 e1
%;d1  c#1c#1  c#1 d1 d1d1 d1
%
%;Anv�nda noter i ref:    9st
%;b1 a1 g1 f#1 f1 e1 d1 c#1 b0
%
%;Totalt anv�nda noter: c2 b1 a1 g1 f#1 f1 e1 d1 c#1 c1 b0 a0  = 12 st



%The note values used through the whole song are:
% Note Name   Hz                     nofSamples@7812.5Hz
% D   Hz(18)  146.8323839587038 Hz   53.206927445904853
% E   Hz(20)  164.8137784564350 Hz   47.401983457742659
% F   Hz(21)  174.6141157165020 Hz   44.741514555925860
% F#  Hz(22) 184.9972113558173 Hz    42.230366299812502
% G#  Hz(24) 207.6523487899727 Hz    37.622979203099938
% A   Hz(25) 220 Hz                  35.511363636363598
% B   Hz(27) 246.9416506280622 Hz    31.637028343051789
% C#  Hz(29) 277.1826309768723 Hz    28.185387996594418
% D   Hz(30) 293.6647679174077 Hz    26.603463722952405

%;Totalt anv�nda noter:
%c2  Hz(28)
%b1  Hz(27)
%a1  Hz(25)
%g1  Hz(23)
%f#1 Hz(22)
%f1  Hz(21)
%e1  Hz(20)
%d1  Hz(18)
%c#1 Hz(17)
%c1  Hz(16)
%b0  Hz(15)
%a0  Hz(13)

%Lowest note:
Hz(13)   %     110.0000000000000
     
%Highest note:
Hz(28)   %     261.6255653005989

% With a sample frequency of 7812.5, this corresponds to certain number of
% samples:

% Some short calculations:
c64Fs = 7812.5;

lowestHz = Hz(13);
highestHz = Hz(28);
nofSamplesInLowestNote = c64Fs / lowestHz    %  71.022727272727252
nofSamplesInHighestNote = c64Fs / highestHz    %   29.861378382589265

% Assume every waveform is 64 bytes
% Then, we could have 128 waveforms = 8kB of waveform tables
% We would need pitch tables, that looked like this:
%pitch_13: 00 01 02 02 03 04 05 05 06 07 08 08 ... 3e 3f 3f 00 01 02 02 03...
%pitch_15
%pitch_16
%pitch_17
%...
%pitch_28: 00 02 04 07 09 0b 0e ... 3e 00 02 05 ...

%Every pitch table would need to be 
% (length of one period) + (length of one "batch" run)
%Assume we want to have 2 render loop runs per frame.
%We would then need to render 312/2 = 156 / 2 = 78 samples per render.
% This means that the pitch tables would occupy something like
%12 * (78 + 64) = 1704 bytes, which is "nothing"...!

%So, let's calculate some pitch tables!
waveformLength = 64;
renderLength = 78;
renderPhaseAdd = zeros(1,40);
renderNofSamplesInThis = zeros(1,40);

for pitchNo=13:28,
    desiredHz = Hz(pitchNo);
    pitchTableLen = 78+72;  % Worst case...
    
    filename = sprintf('pitch_%d.s',pitchNo);
    fid = fopen(filename,'w');
    fprintf(fid,'; Pitch table for Hz(%d).\n',pitchNo);
    fprintf(fid,'; Replay frequency is %d.\n',c64Fs);
    fprintf(fid,'; Desired Hz is %d.\n',desiredHz);
    fprintf(fid,'; this table contains %d values\n',pitchTableLen);
    fprintf(fid,'; Generated on the %s\n',date);
    fprintf(fid,'; Pex Mahoney Tufvesson, 2011\n');
    fprintf(fid,'\n');
    fprintf(fid,'pitch_%d_start:\n',pitchNo);
    index = 0;
    restartNo = 1;
    for i = 1:pitchTableLen
        fprintf(fid,'  .byte %d\n',floor(index));
        index = index + (desiredHz * 64) / c64Fs;
        if (index >= waveformLength)
            index = index - waveformLength;
            fprintf(fid,'pitch_%d_restart%d:\n',pitchNo,restartNo);
            restartNo = restartNo + 1;
        end
        if (i == renderLength)
            someKindOfPhaseIncrement = index;
        end
    end
    fprintf(fid,'pitch_%d_end:\n',pitchNo);
    fprintf(fid,'\n');
    fclose(fid);
    
    pitchNo
    nofSamplesInThis = c64Fs / Hz(pitchNo)

    %Now, assume we render 78 bytes every time.
    %How much shall we increment the pointer inside the waveform for the
    %next rendering?
    
    %If nofSamplesInThis = 64, then we shall increase it with
    % 78-64 = 
    percentage = renderLength / nofSamplesInThis
    
    percentage = percentage - floor(percentage)
    
    %Now, percentage is between 0 and 0.9999999
    %Let's transform this into "how many samples into a waveform.

    phaseAddition = percentage * nofSamplesInThis

    % This is where in a waveform we ended up using this period
    % Now, we need to translate this into
    % "Which index in this pitch table shall we start at to get a pointer 
    % to this sample number
    %
    someKindOfPhaseIncrement
    
    final = someKindOfPhaseIncrement / 64 * nofSamplesInThis 

    
    renderPhaseAdd(pitchNo) = final;
    renderNofSamplesInThis(pitchNo) = nofSamplesInThis;
    
end


filename = sprintf('pitch_increment.s');
fid = fopen(filename,'w');
fprintf(fid,'; Pitch increment tables.\n');
fprintf(fid,'; Replay frequency is %d.\n',c64Fs);
fprintf(fid,'; Render length is %d.\n',renderLength);
fprintf(fid,'; Waveform length is %d.\n',waveformLength);
fprintf(fid,'; Generated on the %s\n',date);
fprintf(fid,'; Pex Mahoney Tufvesson, 2011\n');
fprintf(fid,'\n');
fprintf(fid,'pitchPhaseIncreaseMSB:\n');
for pitchNo=13:28,
    rpMSB = floor(renderPhaseAdd(pitchNo))
    rpLSB = floor((renderPhaseAdd(pitchNo) - rpMSB) * 256)
    nofMSB = floor(renderNofSamplesInThis(pitchNo))
    nofLSB = floor((renderNofSamplesInThis(pitchNo) - nofMSB) * 256)
    fprintf(fid,'  .byte %d ;pitch %d. rpAdd=%d, nofSamples=%d\n', rpMSB, pitchNo, renderPhaseAdd(pitchNo), renderNofSamplesInThis(pitchNo));
end

fprintf(fid,'pitchPhaseIncreaseLSB:\n');
for pitchNo=13:28,
    rpMSB = floor(renderPhaseAdd(pitchNo))
    rpLSB = floor((renderPhaseAdd(pitchNo) - rpMSB) * 256)
    nofMSB = floor(renderNofSamplesInThis(pitchNo))
    nofLSB = floor((renderNofSamplesInThis(pitchNo) - nofMSB) * 256)
    fprintf(fid,'  .byte %d ;pitch %d. rpAdd=%d, nofSamples=%d\n', rpLSB, pitchNo, renderPhaseAdd(pitchNo), renderNofSamplesInThis(pitchNo));
end
fprintf(fid,'pitchNofSamplesInThisMSB:\n');
for pitchNo=13:28,
    rpMSB = floor(renderPhaseAdd(pitchNo))
    rpLSB = floor((renderPhaseAdd(pitchNo) - rpMSB) * 256)
    nofMSB = floor(renderNofSamplesInThis(pitchNo))
    nofLSB = floor((renderNofSamplesInThis(pitchNo) - nofMSB) * 256)
    fprintf(fid,'  .byte %d ;pitch %d. rpAdd=%d, nofSamples=%d\n', nofMSB, pitchNo, renderPhaseAdd(pitchNo), renderNofSamplesInThis(pitchNo));
end
fprintf(fid,'pitchNofSamplesInThisLSB:\n');
for pitchNo=13:28,
    rpMSB = floor(renderPhaseAdd(pitchNo))
    rpLSB = floor((renderPhaseAdd(pitchNo) - rpMSB) * 256)
    nofMSB = floor(renderNofSamplesInThis(pitchNo))
    nofLSB = floor((renderNofSamplesInThis(pitchNo) - nofMSB) * 256)
    fprintf(fid,'  .byte %d ;pitch %d. rpAdd=%d, nofSamples=%d\n', nofLSB, pitchNo, renderPhaseAdd(pitchNo), renderNofSamplesInThis(pitchNo));
end
fclose(fid);


