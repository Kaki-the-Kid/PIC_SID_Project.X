%
% This is a helper script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%


format long;
format compact;
clear;


nof_frames = 23;

i_orig = imread('../graphics/android/android_orig_2.bmp');

si = size(i_orig);  %200 320 3
% Pick out a greyscale version:

i = i_orig(:,:,1);

% And mirror it to make sure that it's symmetric:
width = si(2);
height = si(1);
i(:,width/2:width-1) = i(:,width/2:-1:1);

%Invert it, since rotation sets "outside pixels" to 0
i = 255 - i;

% Now, let's determine the rotation.

% With 1 frame diff is (45/1) = 45', starting at 22.5'
% With 3 frames it's (45/3) = 15' with starting at 7.5' = 7.5, 22.5, 37.5
% With X (odd) frames it's (45/X) = ? starting at (45/X/2).
frame = zeros(nof_frames,height, width, 3);
this_frame = zeros(height, width, 3);

for frame_no = 0:nof_frames-1,
    rot = (frame_no * 45 / nof_frames) + (45 / nof_frames / 2)
    frame(frame_no+1,:,:,1) = imrotate(i,rot,'nearest','crop');
    %Invert it "back" to normal, since rotation sets "outside pixels" to 0
    frame(frame_no+1,:,:,1) = 255 - frame(frame_no+1,:,:,1);
    %Move it a couple of pixels left:
    frame(frame_no+1,:,1:316,1) = frame(frame_no+1,:,5:320,1);
    frame(frame_no+1,:,:,2) = frame(frame_no+1,:,:,1);
    frame(frame_no+1,:,:,3) = frame(frame_no+1,:,:,1);
    dest_filename = sprintf('../graphics/android/a_%d.bmp',frame_no+1);
    this_frame(:,:,:) = frame(frame_no+1,:,:,:);
    imwrite(this_frame, dest_filename, 'bmp');
end


