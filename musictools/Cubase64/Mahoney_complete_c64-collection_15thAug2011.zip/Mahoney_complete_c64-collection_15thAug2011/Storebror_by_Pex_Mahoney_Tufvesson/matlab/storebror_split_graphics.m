%
% This is a helper script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%

% This will read the CSAM V3-generated character screens,
% and split them into separate screens.
% This is just because I'm lazy. It could be done manually as well,
% of course...

format long;
format compact;
clear;

% Takes any song and extracts something from it.
split_len = 1024;
screen_len = 1000;
nof_frames = 34;

filename = sprintf('../graphics/gra_c64_vqs_5.raw');
fid = fopen(filename,'r');

for frame=1:nof_frames,
    frame
    screen = fread(fid,split_len,'uchar');
    dest_filename = sprintf('../demo/matlab_frame_%d.raw',frame);
    fid_dest = fopen(dest_filename,'w');
    count = fwrite(fid_dest,screen(1:screen_len),'uchar');
    fclose(fid_dest);
end
fclose(fid);
