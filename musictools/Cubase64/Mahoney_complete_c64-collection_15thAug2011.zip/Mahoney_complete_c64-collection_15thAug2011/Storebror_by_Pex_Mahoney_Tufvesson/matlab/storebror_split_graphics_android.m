%
% This is a helper script for
%
%   storebror by Pex 'Mahoney' Tufvesson, August 2011
%
%
% Want to know more?  http://mahoney.c64.org
% Want to hear C64 a cappella?  Visa R�ster at http://www.livet.se/visa
% Want a happy life? Do something _not_ requiring electricity! :-D
%

% This will read the CSAM V3-generated character screens,
% and split them into separate screens.
% This is just because I'm lazy. It could be done manually as well,
% of course...

format long;
format compact;
clear;

% Takes any song and extracts something from it.
split_len = 1024;
screen_len = 1000;
nof_frames = 23;

filename = sprintf('../graphics/android/android_5_vqs.raw');
fid = fopen(filename,'r');

for frame=1:nof_frames,
    frame
    screen = fread(fid,split_len,'uchar');
    %Now, select those 23*23 chars that matters. (529 bytes)
    selected_screen = zeros(23,23);
    for row=0:22,
        selected_screen(row*23+1:row*23+23) = screen((row+1)*40+9:(row+1)*40+31);
    end
    dest_filename = sprintf('../demo/android_frame_%d.raw',frame);
    fid_dest = fopen(dest_filename,'w');
%    count = fwrite(fid_dest,screen(1:screen_len),'uchar');
    count = fwrite(fid_dest,selected_screen,'uchar');
    fclose(fid_dest);
end
fclose(fid);
