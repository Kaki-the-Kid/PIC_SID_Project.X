
 Storebror by Pex 'Mahoney' Tufvesson
Released at LCP in Lund, Sweden, 6th of August 2011


You've found the source code for the demo, which to 99.99% of the World's population is
completely unreadable. But, if you're one of the gifted few, have a look around, and
enjoy the reading.

How to build?
You'll need Matlab, which will run all of the scripts in some kind of order.
You'll need something like a windows machine or a mac osx. For mac osx, grab
xcode (which is a 4GB download for getting a single 100kB make program, but
today's computing is full of this bloatware stuff. Beware...). And install
MacPorts (www.macports.org) - and install wine through "sudo ports install wine" and
a lot of patience...

For the graphics, those Matlab scripts will for instance rotate the android image,
producing 23 versions of the image rotated in the first 1/8 of a circle.
Since the android image is symmetric, we'll only need the first 45 degrees of a circle,
and the rest can be calculated on the fly by mirroring and rotating the image, in
8 different ways.

You'll need to run CSAM_v3.0.exe on a windows machine/wine/emulator/whatever to transform
those images into commodore 64 charsets (codebooks) with corresponding character screens.
Thanks to Naveed 'Algorithm' Khugiani for Csam v3.0, it saved me loads of time not having
to write the char selection algorithms myself.

Then, another Matlab script will split the output files from CSAM into separate files to
be pucrunched individually by the Makefile.

Sounds complicated? It is.

The audio is handled by the four Matlab scripts named storebror_0x. These will, in a similar
way as my previous "Cubase64" demo (please read the whitepaper about it, you'll find it at
http://mahoney.c64.org ), select 128 waveforms, 64 bytes in each waveform. Then, make
individual lists for each phrase in the song of which waveform to play where.
It will also generate a number of strange precalculated tables for phase increment and
pitch step which are needed to accomplish the real time calculations of the audio.
The pitch information is discarded, since it will use the pitch of the song instead of the singing.

The main demo is written in the file "demo/main.s". Unfortunately, it contains a mess of
memory movements every now and then, which will make the reading of the source code
complicated. But, the start address is $0258, and you'll have to trace your way through
the code from there. The timer correction routines are placed at $0800, $0900, $0a00,
$0b00, $0c00, $0d00 and $0e00. The audio buffer is the stack between $0100-$01ff.
The screens for the text on the screen are located at $ec00, $f000, $f400, $f800 and $fc00.
The demo uses no sprites, since that would break the timing correction needed for 8-bit
sample playing.

There are 3 audio samples, bass drum, high hat and snare drum. The SID player routine is
based on Rob Hubbard's "Monty on the run", since it's an excellent written music player
for the 6502 CPU. The sample playing is initially played by a plain NMI, then when the
singing requires it, it switches to playing rendered audio from the stack. And, at the
end of the demo (when the android robot starts rotating), the sample playing switches
from using 8-bit samples to using the $d418 volume switching for playing 3-bit samples.
The reason for this is that I needed the clock cycles for the real-time mirroring/rotation
of the android robot screens. If I had to, I could save a couple of clock cycles by removing
the jitter correction for this $d418 sample playing. But I didn't need to...

The main problem of the music was how to get the amplitude of the samples to match the
amplitude of the SID bass instrument. Hence, there's a built-in compressor with a soft
knee in the final volume table, acting as a limiter and volume booster for the samples.

Anyway, that's all of the explanations I'm gonna do this time. If there's something
special you'd like to know more about, you're welcome to contact me!


Best Regards, Pex "Mahoney" Tufvesson, August 2011

ps. If you think my singing sucks, then I'd say it is as good as it needs to be for this task.
The pitch is irrelevant, and the volume as well. I though of making a second recording, but
there was no need for it. I've done better; head over to http://www.livet.se/visa - and
you'll hear singing for real! :-D

---

 Big brother is watching you
 seeing more than he ought to do
 Internet is being monitored
 Are you a criminal?

 Big brother is watching you
 Every cell tower is tracking you
 Swedish military they say
 are reading your email today

 How did it get this cold?
 Big brother doesn't know all
 Love, laughter, a scent of flowers
 That's what we need...
            not tracking towers.

 Beware of big brother
 Seeing more than he ought to do
 1984
 Turns 27 this year


They already know you've downloaded this.


ps. If you want to run this on a real Commodore 64, you'll need
a 6581 SID chip, aka "the old one".

ps2. If you want to try this on a Commodore 64 emulator, please use
a proper SID emulation mode. Use the "reSID-FP" with a 6581 chip.


Credits: Coding and singing by Pex 'Mahoney' Tufvesson
         Original music by Electric Banana Band
         Thanks to Naveed 'Algorithm' Khugiani for Csam v3.0, it saved me loads of time
         Thanks to uwe 'thcm/mdg' anfang for optimization suggestions,
            ...none of the turned out to be useful, though. ;)


If you fail to see the beauty in this, don't bother. You'll find your happiness somewhere else.


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
