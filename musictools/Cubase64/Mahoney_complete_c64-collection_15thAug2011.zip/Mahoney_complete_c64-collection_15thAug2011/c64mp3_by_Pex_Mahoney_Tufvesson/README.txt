
 c64mp3 by Pex 'Mahoney' Tufvesson
Released at Datastorm, February 2010. http://www.datastorm.se


It is true, the Commodore 64 CAN SING!


The song chosen is "Tom's Diner" by Suzanne Vega.

Why?

Snitched from Wikipedia.org:
-----------------------------------------
The "Mother of the MP3"

An article in the now defunct magazine Business 2.0 revealed that "Tom's Diner" was also used by Karlheinz Brandenburg to develop the audio compression scheme known as MP3 at what is now the Fraunhofer Society. He recalled:

    I was ready to fine-tune my compression algorithm...somewhere down the corridor, a
    radio was playing "Tom's Diner". I was electrified. I knew it would be nearly
    impossible to compress this warm a cappella voice.[4]

Brandenburg adopted the song for testing purposes, listening to it again and again each time he refined the scheme, making sure it did not adversely affect the subtlety of Vega's voice. While it is an exaggeration to say that the MP3 compression format is specifically tuned to play the song "Tom's Diner" (an assortment of critically analyzed material was involved in the design of the codec over many years), among some audio engineers this anecdote has earned Vega the informal title "The Mother of the MP3".
-----------------------------


The Commodore 64 c64mp3 replay routine uses all the tricks in the book,
in order to acheive the best sound quality possible:

 * The sound buffer is calculated in the stack, and it wraps
 * Jitter free sample playback, by using NMI IRQ vector pointing to $dd04
 * 8-bit sample output by using SID test bit for resetting oscillators
 * saving clock cycles by JMP $dd0c when exiting an NMI
 * Pitch tables? Good for module playback, but worthless for human voices
 * Dithering noise, to make quantization smoother
 * Phase-aligned wavetables with extracted formants
 * Full 8-bit interpolation between formants with 16 different volume ratios
 * 16 volume levels for resulting audio output
 * self-modifying code, of course
 * critical code run in Zero Page
 * ...while only ~15 assembly instructions per sample available
 * ...and still cpu-time left for a demo!

The c64mp3 encoder uses some seriously advanced signal processing as well:

 * sub-sample pitch detection
 * auto-tuning into constant-pitch audio
 * formant extraction, sub-sample phase-alignment and normalization
 * formant cross correlation and selection
 * consonant detection and extraction
 * run-length encoding of data with _minimal_ unpacking overhead
 * requires 4GB of RAM and 500MB of hard drive space


Now, it's up to you guys to turn this into an avalanche of songs combining
SID sounds, sampled drums _and_ lyrics!

It is true, the Commodore 64 CAN SING! ...but it took some 28 years for it to learn! ;)


ps. Please use a Commodore 64 with a 6581 SID chip. If you want to
try this on a Commodore 64 emulator, please use a proper SID emulation mode.
Use the "reSID-FP" with a 6581 chip.
For instance, with Vice 2.1 (www.viceteam.org), start it with:
x64 -sidengine 7 -soundrate 44100 -soundsync 2 c64mp3.prg


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
