
 c64mp3 decoder

by Pex 'Mahoney' Tufvesson, February 2010.
Released at Datastorm 2010. http://www.datastorm.se

If you want to encode another song, please look through
the encoder folder first. The data from the song is
in the files named SID*.s in this (the decoder) folder.

There are make files, not very complete ones, but they
do the trick for me.

The whole thing, decoder and demo, is included in the
files main.s, 2x2_charset and man_with_hat_inv.bin.

on Linux:  make run
on Win32:  rename makefile_win to makefile, then nmake.exe run

The resulting Commodore 64 executable is in the file
c64mp3.prg

The resulting code is packed with pucrunch by Pasi Ojala.

Sorry for not making the source code easy to follow.
And, the coding is a mess, which it has to be. :-D
But, I never said it would be easy! ;)


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
