
 c64mp3 encoder

by Pex 'Mahoney' Tufvesson, February 2010.
Released at Datastorm 2010. http://www.datastorm.se

For documentation, read through the files

 c63mp3_1analyzePitch.m
 c63mp3_2correlateWaveforms.m
 c63mp3_3simplePlayback.m
 c63mp3_4encodeWaveforms.m
 c63mp3_5analyzeNoise.m
 c63mp3_6encodeNoise.m

For executing the encoding, use Matlab with a
couple of toolboxes, 4GB of RAM, preferrably on
a 64-bit machine. Run the Matlab scrits in the
order above. And some 20 minutes later, copy
all the files named "SID*.s" from the encoder
folder into the decoder folder, and continue there.
And, you'll need some 500MB of free disk space.

I never said it would be easy...! ;)


Have a noise night!

/ Pex 'Mahoney' Tufvesson
http://mahoney.c64.org
http://www.livet.se/visa
