/**
 * This file is a part of JaC64 - a Java C64 Emulator
 * Main Developer: Joakim Eriksson (JaC64.com Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.jac64.com/ 
 * http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jac64;

/**
 *
 * Created: Sun Sep 11 23:16:23 2005
 *
 * @author Joakim Eriksson
 * @version 1.0
 */

public class SIDVoice {
  public int[] intBuffer;
  public int[] generateSound(long cycles) {
    return null;
  };
}
