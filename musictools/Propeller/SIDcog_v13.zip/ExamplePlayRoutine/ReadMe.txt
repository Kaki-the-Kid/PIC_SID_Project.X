
1. Open "ExamplePlayRoutine.spin" and Change the pin configuration to suite your needs.

2. Compile and upload to your propeller.

3. Enjoy