
1. Copy "Lost_friend.dmp" to a SD-card.

2. Open "ExampleSidDumpPlay.spin" and Change the pin configuration to suite your needs.

4. Compile and upload "ExampleSidDumpPlay.spin" to your propeller.

5. Enjoy